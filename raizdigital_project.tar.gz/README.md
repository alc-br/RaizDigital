# RaizDigital

RaizDigital é uma plataforma de nicho voltada para brasileiros que buscam a cidadania estrangeira (principalmente portuguesa e italiana) e precisam localizar certidões civis antigas sem saber em qual cartório o documento está.  Diferentemente de despachantes digitais que exigem que você indique o cartório, o RaizDigital utiliza um motor de busca automatizado para varrer múltiplas fontes públicas de dados e entregar um relatório completo com a localização do documento ou um relatório de buscas negativas.

## Arquitetura

A plataforma é composta por dois componentes principais: um back‑end em Python com **FastAPI**, responsável pela API, persistência e orquestração das buscas, e um front‑end em **React/TypeScript**, que fornece a interface web para os usuários.  O fluxo básico é o seguinte:

```
  [Usuário] --interage--> [Frontend React]
        |                         |
        |  requisita API          |
        v                         v
  [FastAPI] -------> [Celery Worker] --invoca--> [Robôs Selenium]
        |                                         |
        |  grava resultados no Banco de Dados     |
        +--------------<--PostgreSQL/Redis--------+
```

* **Frontend React**: Interface do usuário construída com Vite, React, Material‑UI, Zustand e React Router.  Permite cadastro/login, criação de pedidos, checkout via Stripe (simulado) e visualização de resultados.
* **API (FastAPI)**: Exposição de endpoints REST para autenticação, gestão de pedidos e recebimento de resultados de busca.  Utiliza SQLAlchemy (modo assíncrono) com PostgreSQL, autenticação JWT e integração com Stripe.
* **Celery/Redis**: As tarefas de busca são executadas de forma assíncrona através do Celery.  O Redis atua como broker e backend de resultados.
* **Robôs de Busca**: Implementados com Selenium e BeautifulSoup (simulados nesta versão), cada robô consulta uma fonte específica (RegistroCivil.org.br, FamilySearch.org e TJSPortal) e envia os resultados de volta para a API.

## Pré‑requisitos

- **Docker** e **Docker Compose** instalados em sua máquina.
- Uma chave de API da **Stripe** para pagamentos e o webhook secret (veja `.env.example`).

## Configuração do Ambiente

1. Clone ou copie este repositório.
2. Acesse o diretório `backend` e copie o arquivo `.env.example` para `.env`:

   ```bash
   cd backend
   cp .env.example .env
   ```

3. Edite o arquivo `.env` com as suas configurações:

   - `DATABASE_URL`: URL de conexão com o PostgreSQL (já predefinido para o serviço `db` do docker-compose).
   - `SECRET_KEY`: chave secreta para assinar JWTs.
   - `STRIPE_API_KEY` e `STRIPE_WEBHOOK_SECRET`: credenciais da Stripe.
   - `REDIS_URL`, `CELERY_BROKER_URL`, `CELERY_RESULT_BACKEND`: URLs do Redis.
   - `INTERNAL_API_KEY`: chave interna usada pelo robô para postar resultados.

## Rodando em Desenvolvimento

Com as variáveis de ambiente configuradas, basta subir toda a stack com o **docker‑compose** dentro da pasta `backend`:

```bash
docker-compose up --build
```

Isso iniciará quatro containers:

1. **backend**: o servidor FastAPI escutando em `http://localhost:8000`;
2. **celery_worker**: o worker Celery responsável por executar as tarefas de busca;
3. **db**: banco de dados PostgreSQL;
4. **redis**: instância do Redis usada como broker/result backend.

Após subir os serviços, acesse `http://localhost:8000/docs` para visualizar a documentação interativa gerada pelo FastAPI e testar os endpoints.

Para o front‑end, abra outro terminal, navegue até a pasta `frontend`, instale as dependências e rode o Vite:

```bash
cd frontend
npm install
npm run dev
```

O aplicativo React ficará disponível em `http://localhost:3000` e se comunicará com o backend em `http://localhost:8000` (ajuste a variável `VITE_API_URL` se necessário).

## Build e Deploy para Produção

### Backend

O backend está conteinerizado e pronto para produção.  Para fazer o deploy em um provedor de nuvem (AWS ECS, Google Cloud Run, DigitalOcean App Platform, etc.), siga estes passos gerais:

1. Crie um registro de container e faça o *build* da imagem do backend:

   ```bash
   docker build -t sua-conta/raizdigital-backend:latest backend
   docker push sua-conta/raizdigital-backend:latest
   ```

2. Configure um serviço usando a imagem publicada e defina as variáveis de ambiente (`DATABASE_URL`, `SECRET_KEY`, `STRIPE_API_KEY` etc.) no painel do provedor.

3. Provisione um banco de dados PostgreSQL gerenciado e um serviço Redis (ou use alternativas como SQS/RabbitMQ conforme suporte do provedor) e atualize as URLs no ambiente.

4. Crie um segundo serviço/worker a partir da mesma imagem para executar o comando Celery: `celery -A app.tasks worker -l info`.

### Frontend

Para gerar os arquivos estáticos otimizados do front‑end:

```bash
cd frontend
npm install
npm run build
```

Os arquivos serão produzidos na pasta `dist`.  Para o deploy você pode servir esses arquivos usando um servidor web como o **Nginx** (há um `Dockerfile.prod` pronto para isso) ou hospedá‑los em serviços de sites estáticos como Vercel, Netlify ou AWS S3 + CloudFront.

Para empacotar em uma imagem Docker usando Nginx:

```bash
docker build -t sua-conta/raizdigital-frontend:latest -f frontend/Dockerfile.prod frontend
docker push sua-conta/raizdigital-frontend:latest
```

Depois, crie um serviço que execute essa imagem.  Ela serve os arquivos em porta 80 por padrão.

## Estrutura do Projeto

- **backend/**: código fonte da API, tarefas Celery e robôs de busca.
  - `app/` contém módulos da aplicação (configurações, modelos, esquemas, rotas, robôs e tarefas).
  - `Dockerfile` define a imagem Docker do backend.
  - `docker-compose.yml` orquestra os serviços para desenvolvimento.
  - `.env.example` serve de modelo para as variáveis de ambiente.
- **frontend/**: código fonte da interface web.
  - `src/` contém os componentes, páginas, stores e utilidades.
  - `index.html`, `vite.config.ts` e `tsconfig.json` configuram o Vite.
  - `Dockerfile.prod` gera uma imagem otimizada usando Nginx para servir os arquivos estáticos em produção.

## Observações

Esta implementação inclui um robô de busca simplificado que devolve resultados simulados em vez de realmente acessar os portais externos.  Para uso real em produção, implemente a lógica de scraping em `backend/app/robots/*` utilizando Selenium e BeautifulSoup, respeitando os termos de uso dos sites e considerando técnicas de retenção de sessão, espera por elementos e tratamento de erros.  Os endpoints internos e o Celery foram pensados para que essa substituição seja transparente para o restante da plataforma.
