import { Routes, Route, Navigate, Outlet } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import NewOrderPage from './pages/NewOrderPage';
import CheckoutPage from './pages/CheckoutPage';
import Dashboard from './pages/Dashboard';
import OrderDetailPage from './pages/OrderDetailPage';
import BlogPage from './pages/BlogPage';
import { useAuthStore } from './store/useAuthStore';

function ProtectedRoute() {
  const token = useAuthStore((state) => state.token);
  if (!token) {
    return <Navigate to="/" replace />;
  }
  return <Outlet />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/novo-pedido" element={<NewOrderPage />} />
      <Route path="/checkout/:orderId" element={<CheckoutPage />} />
      <Route path="/blog" element={<BlogPage />} />
      <Route element={<ProtectedRoute />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dashboard/pedido/:orderId" element={<OrderDetailPage />} />
      </Route>
    </Routes>
  );
}
