"""
Security utilities for password hashing and JWT authentication.

This module uses Passlib's ``CryptContext`` to hash and verify
passwords securely.  JWT tokens are generated and verified using
``python-jose``; tokens carry the user ID and expire after a
configurable duration.
"""
from datetime import datetime, timedelta
from typing import Any, Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from ..config import get_settings


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Check that a plaintext password matches its hashed version."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Hash a plaintext password using bcrypt."""
    return pwd_context.hash(password)


def create_access_token(*, data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Generate a JWT token embedding the provided data.

    Args:
        data: Arbitrary key/value pairs to encode in the token (e.g. ``{"user_id": 1}``).
        expires_delta: Optional timedelta to specify token lifetime.  If not
            provided, the default configured expiration is used.

    Returns:
        A signed JWT as a string.
    """
    settings = get_settings()
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.access_token_expire_minutes))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm=settings.jwt_algorithm)
    return encoded_jwt


def verify_token(token: str) -> Optional[int]:
    """Decode a JWT token and return the user ID if valid.

    Returns ``None`` if the token is invalid or expired.
    """
    settings = get_settings()
    try:
        payload: dict[str, Any] = jwt.decode(token, settings.secret_key, algorithms=[settings.jwt_algorithm])
        user_id: int = int(payload.get("user_id"))
        return user_id
    except (JWTError, ValueError, TypeError):
        return None
