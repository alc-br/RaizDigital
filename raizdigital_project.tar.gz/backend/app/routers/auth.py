"""
Authentication endpoints for RaizDigital.

This router implements user registration and login.  Passwords are
hashed before storage, and successful logins return a JWT access
token.  The login endpoint uses the standard OAuth2 password grant.
"""
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .. import models, schemas
from ..database import get_session
from ..utils import security
from ..config import get_settings


router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=schemas.UserOut, status_code=201)
async def register_user(user_in: schemas.UserCreate, session: AsyncSession = Depends(get_session)):
    """Register a new user with an email and password.

    Returns the created user object (without the password).
    """
    # Check if the email is already taken
    result = await session.execute(select(models.User).where(models.User.email == user_in.email))
    existing_user = result.scalar_one_or_none()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = security.get_password_hash(user_in.password)
    user = models.User(email=user_in.email, password_hash=hashed_password)
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user


@router.post("/login", response_model=schemas.Token)
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    session: AsyncSession = Depends(get_session),
):
    """Authenticate a user and return a JWT token on success."""
    result = await session.execute(select(models.User).where(models.User.email == form_data.username))
    user = result.scalar_one_or_none()
    if not user or not security.verify_password(form_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    settings = get_settings()
    access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
    access_token = security.create_access_token(data={"user_id": user.id}, expires_delta=access_token_expires)
    return schemas.Token(access_token=access_token)
